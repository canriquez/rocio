//import suma, { separador } from './librerias/utiles/suma.js'
import multiplicacion, * as utiles from './librerias/utiles/suma.js'

console.log('VAMOS A USAR LA FUNCION')

utiles.suma(11,11)

utiles.separador()
utiles.suma(11,11)

utiles.separador()

utiles.suma(11,11)

utiles.separador()
utiles.suma(11,11)

utiles.separador()
utiles.suma(11,11)

utiles.separador()
utiles.suma(11,11)

utiles.separador()
utiles.suma(11,11)

utiles.separador()
utiles.suma(11,11)

utiles.separador()


multiplicacion(11,11)
