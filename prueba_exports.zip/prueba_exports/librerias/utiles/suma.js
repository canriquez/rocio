export function separador() {
    console.log('=======================================')
}

export function suma(a, b) {
    console.log(` (${a} + ${b}) = `, a+b)
}

export default function multipliacion(a,b) {
    console.log('la multiplicacion es: ', a*b);
}